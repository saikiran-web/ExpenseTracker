Expense Tracker App
This website will track your expense and income and record your expenditures and savings to give you a clear estimate of your balance left and your money.
This website is made using Reactjs and React styled components , hooks , props.

Website is live at link : https://expense-tracker-lokesh.netlify.app/

Demo Video : 

https://user-images.githubusercontent.com/93420193/182840163-a58979be-56f0-403f-95c9-18aff27ee032.mp4

Demo images : 
<img width="958" alt="track1" src="https://user-images.githubusercontent.com/93420193/182840204-a33e60f1-49ef-48bc-b5fd-fcff6b69daa2.png">
<img width="960" alt="track2" src="https://user-images.githubusercontent.com/93420193/182840206-f08404a8-3d99-4f35-9663-f1e3d1cd7371.png">
<img width="960" alt="track4" src="https://user-images.githubusercontent.com/93420193/182840212-22ccbf99-5086-492e-a2ed-81695b5c4fca.png">
